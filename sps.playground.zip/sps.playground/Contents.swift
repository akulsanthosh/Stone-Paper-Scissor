 
 

 //## To start playing :
 
 //There are 3 possible gestures that can be shown -
 //* Stone - show a fist 👊
 //* Paper - show five fingers 🖐
 //* Scissors - show victory sign ✌️
 /*
 You must show the gesture first then tap anywhere to confirm, this will show the computer's choice and accordinly marks will be assigned.
 Continue doing so until either you or AI scores 3 points, the first to get 3 points shall be winner.
 In case both AI and user choose the same, then it will be considered as a draw round and no points shall be awarded.
 Tap on the screen to play again.
 
 ## Note :
 
 * The model may incorrently predit gestures, it depends on the lighting conditions and the focus.
 * Do not keep your hand far away or very near.
 
 */
  
import UIKit
import SpriteKit
import ARKit
import Vision
import PlaygroundSupport

enum HandSign: String {
    case fiveHand = "FiveHand"
    case fistHand = "FistHand"
    case victoryHand = "VictoryHand"
    case noHand = "NoHand"
}

class MyViewController : UIViewController, ARSKViewDelegate, ARSessionDelegate, UIGestureRecognizerDelegate {
    
    var sceneView: ARSKView!
    var uiLabel: UIView!
    var uiScore: UIView!
    var label: UILabel!
    var score: UILabel!
    
    var userGes: String = "NIL"
    var AIGes: String = "NIL"
    var user: Int = 0
    var ai: Int = 0
    
    override func viewDidLoad() {
        sceneView = ARSKView()
        
        uiLabel = UIView()
        uiLabel.backgroundColor = .white
        
        label = UILabel()
        label.text = "Tap anywhere to confirm gesture"
        label.textAlignment = .center
        label.font =  UIFont.systemFont(ofSize: 25)
        
        uiScore = UIView()
        uiScore.backgroundColor = .white
        
        score = UILabel()
        score.textAlignment = .center
        score.text = "USER : \(user) vs AI : \(ai)"
        score.font =  UIFont.systemFont(ofSize: 25)
        
        uiLabel.addSubview(label)
        uiScore.addSubview(score)
        
        sceneView.addSubview(uiLabel)
        sceneView.addSubview(uiScore)
        
        
        let gestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(MyViewController.handleTap(gestureRecognizer:)))
        gestureRecognizer.delegate = self
        sceneView.addGestureRecognizer(gestureRecognizer)
        
        let overlayScene = SKScene()
        overlayScene.scaleMode = .aspectFill
        
        sceneView.delegate = self
        sceneView.presentScene(overlayScene)
        sceneView.session.delegate = self
        
        view.addSubview(sceneView)
        
        sceneView.translatesAutoresizingMaskIntoConstraints = false
        sceneView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0).isActive = true
        sceneView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 0).isActive = true
        sceneView.topAnchor.constraint(equalTo: view.topAnchor, constant: 0).isActive = true
        sceneView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: 0).isActive = true
        
        uiLabel.translatesAutoresizingMaskIntoConstraints = false
        uiLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        uiLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        uiLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 20).isActive = true
        uiLabel.heightAnchor.constraint(equalToConstant: 50).isActive = true
        
        label.translatesAutoresizingMaskIntoConstraints = false
        label.leadingAnchor.constraint(equalTo: uiLabel.leadingAnchor, constant: 0).isActive = true
        label.trailingAnchor.constraint(equalTo: uiLabel.trailingAnchor, constant: 0).isActive = true
        label.topAnchor.constraint(equalTo: uiLabel.topAnchor, constant: 0).isActive = true
        label.bottomAnchor.constraint(equalTo: uiLabel.bottomAnchor, constant: 0).isActive = true
        
        uiScore.translatesAutoresizingMaskIntoConstraints = false
        uiScore.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        uiScore.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        uiScore.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -20).isActive = true
        uiScore.heightAnchor.constraint(equalToConstant: 50).isActive = true
        
        score.translatesAutoresizingMaskIntoConstraints = false
        score.leadingAnchor.constraint(equalTo: uiScore.leadingAnchor, constant: 0).isActive = true
        score.trailingAnchor.constraint(equalTo: uiScore.trailingAnchor, constant: 0).isActive = true
        score.topAnchor.constraint(equalTo: uiScore.topAnchor, constant: 0).isActive = true
        score.bottomAnchor.constraint(equalTo: uiScore.bottomAnchor, constant: 0).isActive = true
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        
        let configuration = ARWorldTrackingConfiguration()
        
        
        sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        
        sceneView.session.pause()
    }
    
    func session(_ session: ARSession, didUpdate frame: ARFrame) {
        
        guard currentBuffer == nil, case .normal = frame.camera.trackingState else {
            return
        }
        
        
        self.currentBuffer = frame.capturedImage
    }
    
    @objc func handleTap(gestureRecognizer: UIGestureRecognizer) {
        let ran = arc4random_uniform(3)
        if ran == 0 {
            self.AIGes = "stone"
        }
        else if ran == 1 {
            self.AIGes = "paper"
        }
        else {
            self.AIGes = "scissor"
        }
        
        classifyCurrentImage()
        
        
        if userGes == "No Hand" {
            label.text = "Sorry! gesture not clear try again"
        }
        else {
        
        label.text = "AI chose \(AIGes) & You chose \(userGes)"
        
        if AIGes != userGes {
            if userGes == "stone" {
                if AIGes == "paper" {
                    ai = ai + 1
                }
                else {
                    user = user + 1
                }
            }
            else if userGes == "paper" {
                if AIGes == "scissor" {
                    ai = ai + 1
                }
                else {
                    user = user + 1
                }
            }
            else {
                if AIGes == "stone" {
                    ai = ai + 1
                }
                else {
                    user = user + 1
                }
            }
            
            score.text = "USER : \(user) vs AI : \(ai)"
        }
        else {
            label.text = "Draw Round! Tap Again"
        }
        
        if ai == 3 || user == 3 {
            if ai == 3 {
                label.text = "AI WON! Tap to play again"
                
            }
            else {
                label.text = "YOU WON! Tap to play again"
            }
            self.ai = 0
            self.user = 0
        }
        }
        
    }
    
    private lazy var classificationRequest: VNCoreMLRequest = {
        do {
            let model = try VNCoreMLModel(for: HandSigns().model)
            let request = VNCoreMLRequest(model: model, completionHandler: { [weak self] request, error in
                self?.processClassifications(for: request, error: error)
            })
            
//            request.imageCropAndScaleOption = .centerCrop
            
//            request.usesCPUOnly = true
            
            return request
        } catch {
            fatalError("Failed to load Vision ML model: \(error)")
        }
    }()
    
    // The pixel buffer being held for analysis; used to serialize Vision requests.
    private var currentBuffer: CVPixelBuffer?
    
    // Queue for dispatching vision classification requests
    private let visionQueue = DispatchQueue(label: "visionQueue")
    
    private func classifyCurrentImage() {
        // Most computer vision tasks are not rotation agnostic so it is important to pass in the orientation of the image with respect to device.
        let orientation = CGImagePropertyOrientation(UIDevice.current.orientation)
        
        if currentBuffer == nil {
            userGes == "No Hand"
            return
        }
        
        let requestHandler = VNImageRequestHandler(cvPixelBuffer: currentBuffer!, orientation: orientation)
        visionQueue.async {
            do {
                // Release the pixel buffer when done, allowing the next buffer to be processed.
                defer { self.currentBuffer = nil }
                try requestHandler.perform([self.classificationRequest])
            } catch {
                print("Error: Vision request failed with error \"\(error)\"")
            }
        }
    }
    
    private var identifierString = ""
    private var confidence: VNConfidence = 0.0
    
    func processClassifications(for request: VNRequest, error: Error?) {
        guard let results = request.results else {
            print("Unable to classify image.\n\(error!.localizedDescription)")
            return
        }
        // The `results` will always be `VNClassificationObservation`s, as specified by the Core ML model in this project.
        let classifications = results as! [VNClassificationObservation]
        
        // Show a label for the highest-confidence result (but only above a minimum confidence threshold).
        if let bestResult = classifications.first {
            switch bestResult.identifier {
            case HandSign.fistHand.rawValue:
                userGes = "stone"
            case HandSign.victoryHand.rawValue:
                userGes = "scissor"
            case HandSign.fiveHand.rawValue:
                userGes = "paper"
            case HandSign.noHand.rawValue:
                userGes = "No Hand"
            default:
                break
            }
        } else {
            identifierString = ""
            confidence = 0
        }
        
    }
    
    
}

extension CGImagePropertyOrientation {
    init(_ deviceOrientation: UIDeviceOrientation) {
        switch deviceOrientation {
        case .portraitUpsideDown: self = .left
        case .landscapeLeft: self = .up
        case .landscapeRight: self = .down
        default: self = .right
        }
    }
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
PlaygroundPage.current.needsIndefiniteExecution = true
